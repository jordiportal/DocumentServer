/**
 * BIW Data Connector - Background Service v2.7.0
 * 
 * Solución basada en análisis del código fuente de ONLYOFFICE.
 * El plugin envía un mensaje "attachEvent" para registrar el evento onToolbarMenuClick.
 */

(function(window, undefined) {
    'use strict';

    let currentWindow = null;
    let isInitialized = false;

    /**
     * Función auxiliar para enviar mensaje de attachEvent
     */
    function sendAttachEvent(eventName) {
        // Método 1: A través de info.type
        if (window.Asc && window.Asc.plugin && window.Asc.plugin.info) {
            let info = window.Asc.plugin.info;
            info.type = "attachEvent";
            info.name = eventName;
            
            try {
                let message = JSON.stringify(info);
                console.log('[BIW v2.7.0] Enviando attachEvent:', eventName);
                
                // Enviar al padre
                if (window.parent && window.parent !== window) {
                    window.parent.postMessage(message, "*");
                }
                // También usar la función global si existe
                if (typeof window.plugin_sendMessage === 'function') {
                    window.plugin_sendMessage(message);
                }
            } catch(e) {
                console.error('[BIW v2.7.0] Error enviando attachEvent:', e);
            }
        }
    }

    /**
     * Inicialización del plugin de fondo
     */
    window.Asc.plugin.init = function(data) {
        if (isInitialized) {
            console.log('[BIW v2.7.0] Plugin ya inicializado');
            return;
        }
        isInitialized = true;
        
        console.log('[BIW v2.7.0] ========================================');
        console.log('[BIW v2.7.0] Plugin de fondo inicializado');
        console.log('[BIW v2.7.0] GUID:', window.Asc.plugin.info.guid);
        console.log('[BIW v2.7.0] ========================================');
        
        // Registrar eventos usando attachEvent message
        console.log('[BIW v2.7.0] Registrando eventos...');
        sendAttachEvent("onToolbarMenuClick");
        sendAttachEvent("onContextMenuClick");
        
        // Registrar UI después de un pequeño delay
        setTimeout(function() {
            registerToolbar();
            registerContextMenu();
        }, 100);
    };

    /**
     * Handler de click en toolbar
     */
    window.Asc.plugin.onToolbarMenuClick = function(id) {
        console.log('[BIW v2.7.0] *** TOOLBAR CLICK *** ID:', id);
        handleButtonClick(id);
    };

    /**
     * Handler de click en menú contextual
     */
    window.Asc.plugin.onContextMenuClick = function(id) {
        console.log('[BIW v2.7.0] *** CONTEXT CLICK *** ID:', id);
        if (id === "biw-ctx-import") {
            openImportWindow();
        }
    };

    /**
     * Manejador común de clicks
     */
    function handleButtonClick(id) {
        console.log('[BIW v2.7.0] handleButtonClick:', id);
        
        switch(id) {
            case "biw-import":
                openImportWindow();
                break;
            case "biw-refresh":
                refreshData();
                break;
            case "biw-settings":
                openSettingsWindow();
                break;
            default:
                console.log('[BIW v2.7.0] ID no reconocido:', id);
        }
    }

    /**
     * Registra la pestaña BIW en el ribbon
     */
    function registerToolbar() {
        console.log('[BIW v2.7.0] Registrando toolbar...');
        
        window.Asc.plugin.executeMethod("AddToolbarMenuItem", [{
            guid: window.Asc.plugin.info.guid,
            tabs: [{
                id: "BIWTab",
                text: "BIW",
                items: [
                    {
                        id: "biw-import",
                        type: "button",
                        text: "Importar Datos",
                        hint: "Abre ventana de importación de datos BIW",
                        icons: "resources/icons/import.svg",
                        disabled: false
                    },
                    {
                        id: "biw-separator",
                        type: "separator"
                    },
                    {
                        id: "biw-refresh",
                        type: "button",
                        text: "Actualizar",
                        hint: "Actualiza los datos de la hoja actual",
                        icons: "resources/icons/refresh.svg",
                        disabled: false
                    },
                    {
                        id: "biw-settings",
                        type: "button",
                        text: "Configuración",
                        hint: "Configuración del conector BIW",
                        icons: "resources/icons/settings.svg",
                        disabled: false
                    }
                ]
            }]
        }], function(result) {
            console.log('[BIW v2.7.0] Toolbar registrado, result:', result);
        });
    }

    /**
     * Registra menú contextual
     */
    function registerContextMenu() {
        console.log('[BIW v2.7.0] Registrando menú contextual...');
        
        window.Asc.plugin.executeMethod("AddContextMenuItem", [{
            guid: window.Asc.plugin.info.guid,
            items: [{
                id: "biw-ctx-import",
                text: "📊 Importar datos BIW"
            }]
        }], function(result) {
            console.log('[BIW v2.7.0] Menú contextual registrado, result:', result);
        });
    }

    /**
     * Abre la ventana de importación
     */
    function openImportWindow() {
        console.log('[BIW v2.7.0] === ABRIENDO VENTANA ===');
        
        if (typeof window.Asc.PluginWindow !== 'undefined') {
            try {
                if (currentWindow) {
                    try { currentWindow.close(); } catch(e) {}
                    currentWindow = null;
                }
                
                currentWindow = new window.Asc.PluginWindow();
                console.log('[BIW v2.7.0] Ventana creada, ID:', currentWindow.id);
                
                currentWindow.attachEvent("onClose", function() {
                    console.log('[BIW v2.7.0] Ventana cerrada');
                    currentWindow = null;
                });
                
                currentWindow.show({
                    url: "window.html",
                    title: "Importar Datos BIW",
                    isModal: true,
                    isResizable: true,
                    size: [500, 550]
                });
                
                console.log('[BIW v2.7.0] Ventana mostrada');
                
            } catch (error) {
                console.error('[BIW v2.7.0] Error:', error);
                fallbackWindow();
            }
        } else {
            console.log('[BIW v2.7.0] PluginWindow no disponible, usando fallback');
            fallbackWindow();
        }
    }

    /**
     * Fallback para abrir ventana
     */
    function fallbackWindow() {
        console.log('[BIW v2.7.0] Usando fallback ShowWindow...');
        
        var frameId = 'biw_' + Date.now();
        
        window.Asc.plugin.executeMethod("ShowWindow", [
            frameId,
            {
                url: "window.html",
                title: "Importar Datos BIW",
                isModal: true,
                isResizable: true,
                size: [500, 550]
            }
        ], function(result) {
            console.log('[BIW v2.7.0] ShowWindow resultado:', result);
        });
    }

    /**
     * Actualiza los datos
     */
    function refreshData() {
        console.log('[BIW v2.7.0] === ACTUALIZAR DATOS ===');
        
        window.Asc.plugin.callCommand(function() {
            var oSheet = Api.GetActiveSheet();
            var oCell = oSheet.GetActiveCell();
            oCell.SetValue("Actualizado: " + new Date().toLocaleTimeString());
            return { success: true };
        }, false, true, function(result) {
            console.log('[BIW v2.7.0] Actualización completada:', result);
        });
    }

    /**
     * Abre configuración
     */
    function openSettingsWindow() {
        console.log('[BIW v2.7.0] === CONFIGURACIÓN ===');
        
        if (typeof window.Asc.PluginWindow !== 'undefined') {
            try {
                var settingsWin = new window.Asc.PluginWindow();
                settingsWin.show({
                    url: "settings.html",
                    title: "Configuración BIW",
                    isModal: true,
                    isResizable: false,
                    size: [400, 350]
                });
            } catch(e) {
                console.error('[BIW v2.7.0] Error configuración:', e);
            }
        }
    }

    // Handlers requeridos
    window.Asc.plugin.button = function(id) {
        console.log('[BIW v2.7.0] button:', id);
    };
    
    window.Asc.plugin.onExternalMouseUp = function() {};
    window.Asc.plugin.onTranslate = function() {};
    window.Asc.plugin.onThemeChanged = function() {};

    // Escuchar mensajes
    window.addEventListener('message', function(event) {
        try {
            var msg = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
            console.log('[BIW v2.7.0] Mensaje recibido:', msg.type || msg);
            
            if (msg.type === 'insertData' && msg.data && msg.data.rows) {
                insertDataToSheet(msg.data.rows);
            }
        } catch(e) {}
    });

    /**
     * Inserta datos en la hoja
     */
    function insertDataToSheet(rows) {
        console.log('[BIW v2.7.0] Insertando', rows.length, 'filas');
        
        window.Asc.plugin.callCommand(function() {
            var oSheet = Api.GetActiveSheet();
            var data = Asc.scope.data;
            
            if (!data || data.length === 0) return { error: "Sin datos" };
            
            var headers = Object.keys(data[0]);
            
            for (var c = 0; c < headers.length; c++) {
                var cell = oSheet.GetRangeByNumber(0, c);
                cell.SetValue(headers[c]);
                cell.SetBold(true);
            }
            
            for (var r = 0; r < data.length; r++) {
                for (var c = 0; c < headers.length; c++) {
                    oSheet.GetRangeByNumber(r + 1, c).SetValue(data[r][headers[c]]);
                }
            }
            
            return { success: true, count: data.length };
        }, false, true, function(result) {
            console.log('[BIW v2.7.0] Inserción completada:', result);
        }, { data: rows });
    }

})(window);
